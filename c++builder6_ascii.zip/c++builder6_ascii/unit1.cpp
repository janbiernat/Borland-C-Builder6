//---------------------------------------------------------------------------
/*
  --== Podstawowy kurs C++Builder'a
  Copyright (c)by Jan T. Biernat 
*/
//Tablica ASCII.
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
  //FormCreate.
  FormResize(Sender);
  Caption = "Tablica ASCII (c)by Jan T. Biernat";
  Application->Title = Caption;
  FormShow(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormResize(TObject *Sender)
{
  //FormResize.
  Width = 329;
  Height = 398;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormShow(TObject *Sender)
{
  //FormShow.
  AnsiString T = "";
  StringGrid1->Font->Name = "Terminal";
  StringGrid1->Font->Size = 16;
  StringGrid1->ColCount = 3;
  StringGrid1->RowCount = 258;
  StringGrid1->Cells[0][0] = " Znak";
  StringGrid1->Cells[1][0] = " Kod";
  StringGrid1->Cells[2][0] = " Hex";
  for(int I = 0; I < 256; I++) {
    T = ""; T = (char)I;
    StringGrid1->Cells[0][I+1] = " "+T;
    StringGrid1->Cells[1][I+1] = " "+IntToStr(I);
    StringGrid1->Cells[2][I+1] = " "+IntToHex(I, 2);
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton1Click(TObject *Sender)
{
  //SpeedButton1Click.
  Application->Terminate();
}
//---------------------------------------------------------------------------

