//---------------------------------------------------------------------------
/*
  --== Podstawowy Kurs C++Builder�a ==--
  Copyright (c)by Jan T. Biernat
*/
#include <vcl.h>
#pragma hdrstop

#include "unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
  //FormCreate.
    Font->Size = 13;
  //Tabliczka mno�enia.
    for(int A=0; A < 10; A++) {
      StringGrid1->Cells[A+1][0] = IntToStr(A+1);
      StringGrid1->ColCount++;
      StringGrid1->Cells[0][A+1] = IntToStr(A+1);
      StringGrid1->RowCount = StringGrid1->RowCount+1;
      for(int B=0; B < 10; B++) {
        StringGrid1->Cells[A+1][B+1] = IntToStr((A+1)*(B+1));
      }
    }
    StringGrid1->ColCount--;
    StringGrid1->RowCount--;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormResize(TObject *Sender)
{
  //FormResize.
    Width = 459; Height = 356;
}
//---------------------------------------------------------------------------
