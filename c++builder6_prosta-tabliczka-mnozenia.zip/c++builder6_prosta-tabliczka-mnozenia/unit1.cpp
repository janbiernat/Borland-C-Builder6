//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
/*
  --== Prosta tabliczka mno�enia ==--
  Copyright (c)by Jan T. Biernat
  Borland C++Builder6 - Kurs podstawowy
*/
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
  //FormCreate.
    FormResize(Sender);
    Caption = "Prosta tabliczka mno�enia (c)by Jan T. Biernat";
    Application->Title = Caption;
    FormShow(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormResize(TObject *Sender)
{
  //FormResize.
    Width = 708;
    Height = 295;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormShow(TObject *Sender)
{
  //FormShow.
    A = 0; B = 0; Licznik = 0; //Wyzerowanie zmiennych globalnych.
    Odp = ""; Pyt = "";
    //Losowanie liczb.
      srand(time(NULL)); //Zainicjowanie generatora liczb pseudolosowych.
      A = rand()%11; /*Wylosowanie jednej liczby z przedzia�u liczb
                       od 0 do 10 i przypisanie wylosowanej liczby do
                       zmiennej liczbowej ca�kowitej "A".*/
      B = rand()%11;
      Pyt = IntToStr(A)+" x "+IntToStr(B)+" = ";
      Label1->Caption = Pyt;
      Label2->Caption = ""; 
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormKeyPress(TObject *Sender, char &Key)
{
  //FormKeyPress - Obs�uga klawiatury numerycznej.
    if(Key == char(27)) { Application->Minimize(); }
    else if(Key == char(8)) { Odp = ""; Licznik = 0; }
         else if((Key > 47) && (Key < 58)) {
                if(Licznik < 3) { Odp += char(Key); Licznik++; }
              } else if((Key == char(13)) && (Odp != "")) {
                       //Sprawd� poprawno�� odpowiedzi.
                         if(StrToInt(Odp) == (A*B)) {
                           Label2->Font->Color = clBlack;
                           Label2->Caption = "Doskonale!";
                           Sleep(222); FormShow(Sender);
                         } else {
                                  Label2->Font->Color = clRed;
                                  Label2->Caption = "Oj! Fatalnie!";
                                  Odp = ""; Licznik = 0;
                                }
                     }
    Label1->Caption = Pyt+Odp; //Wy�wietl pytanie z odpowiedzi�.
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton1Click(TObject *Sender)
{
  //SpeedButton1Click.
    Application->Terminate();
}
//---------------------------------------------------------------------------
