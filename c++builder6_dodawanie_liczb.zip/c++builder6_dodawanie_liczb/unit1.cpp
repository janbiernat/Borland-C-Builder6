//---------------------------------------------------------------------------
/*
  --== Podstawowy Kurs C++Builder�a ==--
  Copyright (c)by Jan T. Biernat
*/
//Dodawanie liczb.

#include <vcl.h>
#pragma hdrstop

#include "unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
  //W tym miejscu umieszcza si� warto�ci pocz�tkowe np. zmiennych.
    iSumowanie = 0;
    Memo1->Modified = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
  //FormCreate.
    Caption = "Dodawanie liczb";
    Application->Title = Caption;
    FormResize(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormResize(TObject *Sender)
{
  //FormResize - Ustawienie sta�ej szeroko�ci i wysoko�ci formatki.
  Width = 338; Height = 353;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormShow(TObject *Sender)
{
  //FormShow.
    Font->Size = 13;
  //Wyczyszczenie komponent�w.
    Memo1->Lines->Clear();
    Edit1->Text = "";
    Edit1Change(Sender);
    try {   Edit1->SetFocus(); }
    catch (...) { }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Edit1Change(TObject *Sender)
{
  //Edit1Change - Sprawdzenie, czy zosta�a podana liczba.
    Edit1->Color = clWindow;
    BitBtn1->Enabled = false;
    if(Trim(Edit1->Text) != "") {
      try {
            StrToFloat(Trim(Edit1->Text));
            BitBtn1->Enabled = true;
          }
      catch (...) {
                    BitBtn1->Enabled = false;
                    Edit1->Color = clRed;
                  }
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BitBtn1Click(TObject *Sender)
{
  //BitBtn1Click - Sumowanie podanych liczb.
    if(Memo1->Modified == true) {
      Memo1->Lines->Add("+"+Trim(Edit1->Text));
      Memo1->Lines->Add("------------------------");
    }
  //Sumuj podane liczby.
    iSumowanie = iSumowanie+StrToFloat(Trim(Edit1->Text));
  //Wprowad� dane do komponentu.
    Memo1->Lines->Add(FloatToCurr(iSumowanie));
    Edit1->Text = "";
    try {   Edit1->SetFocus(); }
    catch (...) { }
}
//---------------------------------------------------------------------------

