//---------------------------------------------------------------------------
/*
  --== Podstawowy Kurs C++Builder ==--
  Copyright (c)by Jan T. Biernat
*/
//Zegarek cyfrowy - prosty.
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
  //FormCreate.
  FormResize(Sender);
  Caption = "Zegarek cyfrowy - prosty for WinXP (c)by Jan T. Biernat";
  Application->Title = Caption;
  FormShow(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormResize(TObject *Sender)
{
  //FormResize.
  Width = 567;
  Height = 206;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormShow(TObject *Sender)
{
  //FormShow.
  Label1->Width = 243; Label1->AutoSize = false;
  Label1->Caption = FormatDateTime("HH:MM", Now());
  Label2->Width = 90; Label2->AutoSize = false;
  Label2->Caption = FormatDateTime(".SS", Now());
  Timer1Timer(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
  //Timer1Timer.
  Timer1->Interval = 1000;
  Timer1->Enabled = true;
  //=
  Label1->Caption = FormatDateTime("hh:mm", Now());
  Label2->Caption = FormatDateTime(".ss", Now());
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton1Click(TObject *Sender)
{
  //SpeedButton1Click - Zamknij program.
  Application->Terminate();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormKeyPress(TObject *Sender, char &Key)
{
  //FormKeyPress Obs�uga klawiatury.
  if(Key == char(27)) { Application->Minimize(); }
  else if((Key == char(122)) || (Key == char(90))) { SpeedButton1Click(Sender); }
}
//---------------------------------------------------------------------------
