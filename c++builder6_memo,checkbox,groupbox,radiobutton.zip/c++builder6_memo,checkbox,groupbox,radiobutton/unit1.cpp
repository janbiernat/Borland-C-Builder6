//---------------------------------------------------------------------------
/*
  --== Podstawowy Kurs C++Builder�a ==--
  Copyright (c)by Jan T. Biernat
*/
#include <vcl.h>
#pragma hdrstop

#include "unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

const AnsiString tZG_OpisKlawisza = "Pe�ny ekran";

void __fastcall TForm1::FormCreate(TObject *Sender)
{
  //FormCreate.
    Memo1->Lines->Clear(); //Wyczyszczenie zawarto�ci komponentu MEMO.
    Button1->Caption = tZG_OpisKlawisza;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormShow(TObject *Sender)
{
  //FormShow.
    Font->Size = 13;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::CheckBox1Click(TObject *Sender)
{
  //CheckBox1Click.
    Memo1->ReadOnly = CheckBox1->Checked; /*Wy��czenie lub w��czenie
                                            edycji w komponencie MEMO.*/
}
//---------------------------------------------------------------------------

void __fastcall TForm1::CheckBox2Click(TObject *Sender)
{
  //CheckBox2Click.
    if(CheckBox2->Checked == true) { Memo1->ScrollBars = ssBoth; }
    else { Memo1->ScrollBars = ssNone; }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton1Click(TObject *Sender)
{
  //RadioButton1Click.
    if(RadioButton1->Checked == true) { Memo1->Color = clWindow; }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton2Click(TObject *Sender)
{
  //RadioButton2Click.
    if(RadioButton2->Checked == true) { Memo1->Color = clRed; }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton3Click(TObject *Sender)
{
  //RadioButton3Click.
    if(RadioButton3->Checked == true) { Memo1->Color = clGreen; }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton4Click(TObject *Sender)
{
  //RadioButton4Click.
    if(RadioButton4->Checked == true) { Memo1->Color = clBlue; }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::RadioButton5Click(TObject *Sender)
{
  //RadioButton5Click.
    if(RadioButton5->Checked == true) { Memo1->Color = clYellow; }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
  //Button1Click.
    const AnsiString tPrzywroc = "Przywr��";
    if(Button1->Caption == tZG_OpisKlawisza) {
      Width = Screen->Width;
      Height = Screen->Height;
      Left = 0;
      Top = 0;
      Button1->Caption = tPrzywroc;
    } else if(Button1->Caption == tPrzywroc) {
             Width = 819;
             Height = 385;
             Left = (Screen->Width % 2)-(Width % 2);
             Top = (Screen->Height % 2)-(Height % 2);
             Button1->Caption = tZG_OpisKlawisza;
           }
}
//---------------------------------------------------------------------------

