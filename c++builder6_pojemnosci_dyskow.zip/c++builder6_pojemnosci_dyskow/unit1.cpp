//---------------------------------------------------------------------------
/*
  --== Podstawowy Kurs C++Builder�a ==--
  Copyright(c) by Jan T. Biernat
*/
//Pojemno�� dysk�w.
#include <vcl.h>
#pragma hdrstop

#include "unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
  //FormCreate.
  FormResize(Sender);
  Caption = "Wy�wietl pojemno�� dysk�w (c)by Jan T. Biernat";
  Application->Title = Caption;
  FormShow(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormResize(TObject *Sender)
{
  //FormResize.
  Width = 1105;
  Height = 305;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormShow(TObject *Sender)
{
  //FormShow.
  StringGrid1->RowCount = 2;
  StringGrid1->ColCount = 5;
  StringGrid1->FixedRows = 1;
  StringGrid1->FixedCols = 0;
  StringGrid1->DefaultRowHeight = 24;
  StringGrid1->Options << goFixedVertLine << goFixedHorzLine << goVertLine << goHorzLine << goRowSelect;
  //Szeroko�� kolumn i opis.
    StringGrid1->ColWidths[0] = 35; StringGrid1->Cells[0][0] = " LP";
    StringGrid1->ColWidths[1] = 50; StringGrid1->Cells[1][0] = " Dysk";
    StringGrid1->ColWidths[2] = 244; StringGrid1->Cells[2][0] = " Pojemno�� (w bajtach)";
    StringGrid1->ColWidths[3] = 311; StringGrid1->Cells[3][0] = " Zaj�te miejsce (w bajtach)";
    StringGrid1->ColWidths[4] = 311; StringGrid1->Cells[4][0] = " Wolne miejsce (w bajtach)";
  //Lista dost�pnych dysk�w lub/i partycji.
    short int iLicznik = 0, iJakiProcent = 0;
    __int64 iPojemnosc = 0, iWolne = 0, iZajete = 0;
    AnsiString T = "";
    for(int I=0; I < 26; I++) {
      iPojemnosc = 0; iPojemnosc = DiskSize(I+1);
      iWolne = 0; iWolne = DiskFree(I+1);
      iZajete = 0; iZajete = iPojemnosc-iWolne;
      iJakiProcent = 0; iJakiProcent = iWolne*100/iPojemnosc;
      if(iPojemnosc > -1) {
        iLicznik++;
        T = ""; T = (char)(65+I);
        StringGrid1->Cells[0][iLicznik] = " "+IntToStr(iLicznik);
        StringGrid1->Cells[1][iLicznik] = " "+T+":";
        StringGrid1->Cells[2][iLicznik] = " "+FormatFloat("0#,", iPojemnosc);
        StringGrid1->Cells[3][iLicznik] = " "+FormatFloat("0#,", iZajete)
                                         +" ("+IntToStr(100-iJakiProcent)+"%)";
        StringGrid1->Cells[4][iLicznik] = " "+FormatFloat("0#,", iWolne)
                                         +" ("+IntToStr(iJakiProcent)+"%)";
        StringGrid1->RowCount++;
      }
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton1Click(TObject *Sender)
{
  //SpeedButton1Click.
  Application->Terminate();
}
//---------------------------------------------------------------------------

