//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
/*
  --== Timer ==--
  Copyright (c)by Jan T. Biernat
  Borland C++Builder6 - Kurs podstawowy.
*/
AnsiString CzasZeroPrzed(AnsiString Str = "") {
  //CzasZeroPrzed.
    if(Str.Length() == 1) { return "0"+Str; } else { return Str; }
}
short int CzasSpr(AnsiString Str = "") {
  //CzasSpr - Funkcja sprawdza, czy wprowadzony czas jest prawid�owy.
    short int G = 0, M = 0, S = 0;
    if((Str != "") && (Str.Length() == 8)) {
      G = StrToIntDef(Str.SubString(1, 2), -1);
      M = StrToIntDef(Str.SubString(4, 2), -1);
      S = StrToIntDef(Str.SubString(7, 2), -1);
      if((G > -1) && (G < 24)
      && (M > -1) && (M < 60)
      && (S > -1) && (S < 60)) { return 1; } else { return 0; }
    } else { return -1; }
}
AnsiString CzasOdliczajWtyl(AnsiString Str = "") {
  //CzasOdliczajWtyl.
    short int iGodzina = 0, iMinuta = 0, iSekunda = 0;
    if((Str != "") && (Str.Length() == 8)) {
      iGodzina = StrToInt(Str.SubString(1, 2));
      iMinuta = StrToInt(Str.SubString(4, 2));
      iSekunda = StrToInt(Str.SubString(7, 2));
      //Odliczaj czas w ty�.
       if(iSekunda == 0) {
         iSekunda = 59;
         if(iMinuta == 0) {
           iMinuta = 59;
           if(iGodzina == 0) { iGodzina = 23; } else { iGodzina--; }
         } else { iMinuta--; }
       } else { iSekunda--; }
       return CzasZeroPrzed(IntToStr(iGodzina))
         +':'+CzasZeroPrzed(IntToStr(iMinuta))
         +':'+CzasZeroPrzed(IntToStr(iSekunda));
    } else { return ""; }
}
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
  //FormCreate.
    Caption = "Timer (c)by Jan T. Biernat";
    Application->Title = Caption;
    FormResize(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormResize(TObject *Sender)
{
  //FormResize.
    Width = 624; Height = 299;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormShow(TObject *Sender)
{
  //FormShow.
    Str = ""; Label1->Tag = 0;
    Timer1Timer(Sender);
    Timer1->Enabled = true;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormKeyPress(TObject *Sender, char &Key)
{
  //FormKeyPress - Obs�uga klawiatury.
    if(Key == char(27)) { Application->Minimize(); }
    else if(Key == char(32)) { Label1->Tag = 1; Timer1->Enabled = false; } 
    //Wprowadzenie nowego czasu.
      if(Label1->Tag == 1) {
        if(Str.Length() < 9) {
          if((Key > 47) && (Key < 59)) { Str += char(Key); }
        }
        if(Key == char(8)) { Str = ""; }
        else if(Key == char(13)) {
               //Uruchomienie nowego odliczania.
                 if(CzasSpr(Str) > 0) { Label1->Tag = 0; Timer1->Enabled = true; }
             }
        Label1->Caption = Str;
      }
  /*
    Legenda:
      SPACJA - Wprowadzenie nowego czasu.
      ENTER  - Zatwierdzenie nowego czasu.
  */
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SpeedButton2Click(TObject *Sender)
{
  //SpeedButton2Click - Zamknij program.
    Application->Terminate();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
  //Timer1Timer.
    Timer1->Interval = 1000;
    Label1->Caption = CzasOdliczajWtyl(Label1->Caption);
    if(Label1->Caption == "00:00:00") {
      //Zatrzymanie odliczania.
        Timer1->Enabled = false; Label1->Tag = 1;
        Application->Restore();
    }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Label1DblClick(TObject *Sender)
{
  //Label1DblClick - W��cz mo�liwo�� wprowadzenia nowego czasu.
    Label1->Tag = 1; Timer1->Enabled = false; 
}
//---------------------------------------------------------------------------
